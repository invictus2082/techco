Development moved to https://gitlab.com/blacknet-ninja

https://techco.org/ aims to continue on TechCo chain.
